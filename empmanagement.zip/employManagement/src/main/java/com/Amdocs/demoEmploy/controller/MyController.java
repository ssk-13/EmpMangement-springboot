package com.Amdocs.demoEmploy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Amdocs.demoEmploy.entity.Employ;
import com.Amdocs.demoEmploy.service.EmployServiceImpl;

@RestController
public class MyController {
	
	@Autowired
	private EmployServiceImpl employService;
	
	@PostMapping("/add")
	public String add(@RequestBody Employ employ) {
		employService.saveEmploy(employ);
		return "employ Added Successfully";
	}
	
	@GetMapping("/getAll")
	public List<Employ> getAllemploy(){
		return employService.getAllEmploy();
	}
	
	@GetMapping("/getById/{id}")
	public Employ getEmployById(@PathVariable int id) {
	    return employService.getEmployById(id);
	}
	
	@PutMapping("/update")
	public Employ upst(@RequestBody Employ employ)
	{
		return employService.updateEmploy(employ);
    }
	
	@DeleteMapping("/delete")
	public void dele(@RequestBody Employ employ)
	{
		employService.deleteEmploy(employ);
	}
	
	
}
