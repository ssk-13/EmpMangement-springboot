package com.Amdocs.demoEmploy.service;

import java.util.List;

import com.Amdocs.demoEmploy.entity.Employ;

public interface EmployService {
	
	public Employ saveEmploy(Employ employ);
	public List<Employ> getAllEmploy();
	public void deleteEmploy(Employ employ);
	public Employ updateEmploy(Employ employ);
	
	
	public Employ getEmployById(int id);
	

}
