package com.Amdocs.demoEmploy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoEmploytApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoEmploytApplication.class, args);
	}

}
