package com.Amdocs.demoEmploy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Amdocs.demoEmploy.entity.Employ;
import com.Amdocs.demoEmploy.repo.EmploytRepo;
@Service
public class EmployServiceImpl implements EmployService {
	
	
	@Autowired
	EmploytRepo sr;
	public EmployServiceImpl(EmploytRepo employrepo) {
		this.sr = employrepo;
	}
	
		
	@Override
	public Employ saveEmploy(Employ employ) {
		// TODO Auto-generated method stub
		return sr.save(employ);
	}
	
	

	@Override
	public List<Employ> getAllEmploy() {
		// TODO Auto-generated method stub
		return sr.findAll();
	}


	@Override
	public void deleteEmploy(Employ employ) {
		// TODO Auto-generated method stub
		sr.delete(employ);
	}


	@Override
	public Employ updateEmploy(Employ employ) {
		// TODO Auto-generated method stub
		return sr.save(employ);
	}

	@Override
	public Employ getEmployById(int id) {
		// TODO Auto-generated method stub
		return sr.findById(id).orElse(null);
	}}

